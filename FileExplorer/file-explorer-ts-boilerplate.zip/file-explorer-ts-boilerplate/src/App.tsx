import React from "react";

export default function App() {
  return (
    <div className="App">
      Please read the <code>README.md</code> before starting!
    </div>
  );
}
